#!/bin/bash
pymol 1m1n.pml
