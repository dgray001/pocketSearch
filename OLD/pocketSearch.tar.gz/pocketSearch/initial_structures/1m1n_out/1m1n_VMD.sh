#!/bin/bash
vmd 1m1n_out.pdb -e 1m1n.tcl
